package helpers

import "fmt"

func TotalPrice() {
	fmt.Println("Some helper functions comes here")
}
